package com.example.exception_handling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
